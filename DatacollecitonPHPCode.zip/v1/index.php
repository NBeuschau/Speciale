<?php

require_once '../include/DbHandler.php';
require '.././libs/Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

// User id from db - Global Variable
$user_id = NULL;



//---------------------data analysis and extraction


$app->get('/getdatabaseline', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


            $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataBaseline($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
                $tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
//                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
  //              $tmp["detected"] = $ransomware["Detected"];
    //            $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });








$app->get('/getdatahp1', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataHP1($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	
	
	
	
	$app->get('/getdatahp2', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataHP2($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });




		
		$app->get('/getdatahp5', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataHP5($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });


		
		
		
		
		
		
	$app->get('/getdatahp10', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataHP10($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });	
		
		
		
$app->get('/getdatash3', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataSH3($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
		
		
		
		
		$app->get('/getdatash5', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataSH5($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
		$app->get('/getdatash10', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataSH10($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
		
		$app->get('/getdatash15', function() use ($app) {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings


	    $RansomwareName = $app->request->params('RansomwareName');

            $result = $db->getDataSH15($RansomwareName);

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
		$tmp["fecthed"] = $ransomware["Fetched"];
                $tmp["started"] = $ransomware["Started"];
                $tmp["posted"] = $ransomware["Posted"];
                $tmp["monitorStatus"] = $ransomware["MonitorStatus"];
                $tmp["monitorCount"] = $ransomware["MonitorCount"];
                $tmp["countChangedFiles"] = $ransomware["CountChangedFiles"];
                $tmp["countDeletedFiles"] = $ransomware["CountDeletedFiles"];
                $tmp["countNewFiles"] = $ransomware["CountNewFiles"];
                $tmp["countFilemonObservations"] = $ransomware["CountFilemonObservations"];
                $tmp["cpu"] = $ransomware["CPU"];
                $tmp["ram"] = $ransomware["RAM"];
                $tmp["hdd"] = $ransomware["HDD"];
                $tmp["threadCount"] = $ransomware["ThreadCount"];
                $tmp["handleCount"] = $ransomware["HandleCount"];
                $tmp["listChangedFiles"] = $ransomware["ListChangedFiles"];
                $tmp["listDeletedFiles"] = $ransomware["ListDeletedFiles"];
                $tmp["listNewFiles"] = $ransomware["ListNewFiles"];
                $tmp["listFilemonObservations"] = $ransomware["ListFilemonObservations"];
                $tmp["nameOfShutdownRansomware"] = $ransomware["NameOfShutdownRansomware"];
                $tmp["detected"] = $ransomware["Detected"];
                $tmp["shutdown"] = $ransomware["Shutdown"];


              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });

//------------------------QuickTester ransomware code
$app->get('/getquickransomware', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getQuickRansomware();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });



$app->post('/postquickfetched', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postQuickFetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postquickposted', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
	    $FileChangedOnHash = $app->request->params('FileChangedOnHash');
            $FileChangedOnWatcher = $app->request->params('FileChangedOnWatcher');
            $Active = $app->request->params('Active');

            $db = new DbHandler();
            $res = $db->postQuickPosted($RansomwareName, $FileChangedOnHash, $FileChangedOnWatcher, $Active);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->get('/getquickhost', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getQuickHost();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });


		
//------------------------BaselineTester ransomware code
	$app->get('/getbaseransomware', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getBaseRansomware();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/postbasefetched', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postBaseFetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/postbaseposted', function() use ($app) {
            // check for required params
//            verifyRequiredParams(array('RansomwareName'));
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params
			
            $RansomwareName = $data["RansomwareName"];
			$MonitorStatus = $data["MonitorStatus"];
			$MonitorCount = $data["MonitorCount"];
			$CountChangedFiles = $data["CountChangedFiles"];
			$CountDeletedFiles =  $data["CountDeletedFiles"];
			$CountNewFiles = $data["CountNewFiles"];
			$CountFilemonObservations = $data["CountFilemonObservations"];
			$CPU = $data["CPU"];
			$RAM = $data["RAM"];
			$HDD = $data["HDD"];
			$ThreadCount = $data["ThreadCount"];
			$HandleCount = $data["HandleCount"];
			$ListChangedFiles = $data["ListChangedFiles"];
			$ListDeletedFiles = $data["ListDeletedFiles"];
			$ListNewFiles = $data["ListNewFiles"];
			$ListFilemonObservations = $data["ListFilemonObservations"];
			
            $db = new DbHandler();
            $res = $db->postBasePosted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/postbasetaken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postBaseTaken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postbasetested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postBaseTested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });

	$app->get('/getbasehost', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getBaseHost();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
	$app->post('/postbasestarted', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postBaseStarted($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
//------------------------HoneyPot 1 PROCENT ransomware code
	$app->get('/gethp1ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getHP1Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/posthp1fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP1Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/posthp1posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postHP1Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/posthp1taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP1Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/posthp1tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP1Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		$app->get('/gethp1host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getHP1Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
			$app->post('/posthp1started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postHP1Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
//------------------------Honeypot 2 PROCENT  ransomware code
	$app->get('/gethp2ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getHP2Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/posthp2fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP2Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/posthp2posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postHP2Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/posthp2taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP2Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/posthp2tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP2Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


	$app->get('/gethp2host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getHP2Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
		$app->post('/posthp2started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postHP2Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });

//------------------------Honeypot 5 PROCENT ransomware code
	$app->get('/gethp5ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getHP5Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/posthp5fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP5Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/posthp5posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postHP5Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/posthp5taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP5Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/posthp5tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP5Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });

			$app->get('/gethp5host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getHP5Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });

			$app->post('/posthp5started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postHP5Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
//------------------------Honeypot 10 PROCENT ransomware code
			$app->get('/gethp10ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getHP10Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/posthp10fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP10Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/posthp10posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postHP10Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/posthp10taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP10Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/posthp10tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postHP10Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->get('/gethp10host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getHP10Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
		
		$app->post('/posthp10started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postHP10Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		
//------------------------shannon3 PROCENT ransomware code
	$app->get('/getsh3ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getSH3Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/postsh3fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH3Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/postsh3posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postSH3Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/postsh3taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH3Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postsh3tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH3Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		$app->get('/getsh3host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getSH3Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
			$app->post('/postsh3started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postSH3Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });		
		
		
		
//------------------------shannon5 PROCENT ransomware code
	$app->get('/getsh5ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getSH5Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/postsh5fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH5Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/postsh5posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postSH5Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/postsh5taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH5Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postsh5tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH5Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		$app->get('/getsh5host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getSH5Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
			$app->post('/postsh5started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postSH5Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });		
		
		

//------------------------shannon10 PROCENT ransomware code
	$app->get('/getsh10ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getSH10Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/postsh10fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH10Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/postsh10posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postSH10Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/postsh10taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH10Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postsh10tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH10Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		$app->get('/getsh10host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getSH10Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
			$app->post('/postsh10started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postSH10Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });		
		
				
		
//------------------------shannon15 PROCENT ransomware code
	$app->get('/getsh15ransomware', function() {
            $response = array();
            $db = new DbHandler();
            $result = $db->getSH15Ransomware();
            $response["ransomware"] = array();

            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
	
	$app->post('/postsh15fetched', function() use ($app) {
            verifyRequiredParams(array('RansomwareName'));
            $response = array();

            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH15Fetched($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
	$app->post('/postsh15posted', function() use ($app) {
            
            $response = array();

$json = $app->request->getBody();
$data = json_decode($json,true);

            // reading post params

            $RansomwareName = $data["RansomwareName"];
                        $MonitorStatus = $data["MonitorStatus"];
                        $MonitorCount = $data["MonitorCount"];
                        $CountChangedFiles = $data["CountChangedFiles"];
                        $CountDeletedFiles =  $data["CountDeletedFiles"];
                        $CountNewFiles = $data["CountNewFiles"];
                        $CountFilemonObservations = $data["CountFilemonObservations"];
                        $CPU = $data["CPU"];
                        $RAM = $data["RAM"];
                        $HDD = $data["HDD"];
                        $ThreadCount = $data["ThreadCount"];
                        $HandleCount = $data["HandleCount"];
                        $ListChangedFiles = $data["ListChangedFiles"];
                        $ListDeletedFiles = $data["ListDeletedFiles"];
                        $ListNewFiles = $data["ListNewFiles"];
                        $ListFilemonObservations = $data["ListFilemonObservations"];
			$NameOfShutdownRansomware = $data["NameOfShutdownRansomware"];
			$Detected = $data["Detected"];
			$Shutdown = $data["Shutdown"];


            // reading post params
            $db = new DbHandler();
            $res = $db->postSH15Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });



$app->post('/postsh15taken', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH15Taken($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });


$app->post('/postsh15tested', function() use ($app) {
            // check for required params
            verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');

            $db = new DbHandler();
            $res = $db->postSH15Tested($RansomwareName);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });
		
		$app->get('/getsh15host', function() {
            $response = array();
            $db = new DbHandler();
//            $headers = apache_request_headers();
            //$barName = $headers['barName'];
            // fetching all bar ratings
            $result = $db->getSH15Host();

//            $response["error"] = false;
            $response["ransomware"] = array();

            // looping through result and preparing bar array
            while ($ransomware = $result->fetch_assoc()) {
              $tmp = array();
              $tmp["ransomware"] = $ransomware["RansomwareName"];
              array_push($response["ransomware"], $tmp);
            }

            echoRespnse(200, $response);
        });
		
			$app->post('/postsh15started', function() use ($app) {
            // check for required params
            //verifyRequiredParams(array('RansomwareName'));
            $response = array();


            // reading post params
            $RansomwareName = $app->request->params('RansomwareName');
			$Started = $app->request->params('Started');

            $db = new DbHandler();
            $res = $db->postSH15Started($RansomwareName, $Started);

            if ($res == 1 || $res == TRUE) {
                $response["error"] = false;
                $response["message"] = "Your rating has been submitted, thank you :-)";
            } else {
                $response["error"] = true;
                $response["message"] = "Oops! An error occured while submitting your data. Have another try";
                        }
            echoRespnse(201, $response);
        });		
		
		
		
		
//------------------------Helper methods
		
function verifyRequiredParams($required_fields) {
    $error = false;
    $error_fields = "";
    $request_params = array();
    $request_params = $_REQUEST;
    // Handling PUT request params
    if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
        $app = \Slim\Slim::getInstance();
        parse_str($app->request()->getBody(), $request_params);
    }
    foreach ($required_fields as $field) {
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        // Required field(s) are missing or empty
        // echo error json and stop the app
        $response = array();
        $app = \Slim\Slim::getInstance();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echoRespnse(400, $response);
        $app->stop();
    }
}		
		
function echoRespnse($status_code, $response) {
    $app = \Slim\Slim::getInstance();
    // Http response code
    $app->status($status_code);

    // setting response content type to json
    $app->contentType('application/json');

    echo json_encode($response);
}

$app->run();
?>
