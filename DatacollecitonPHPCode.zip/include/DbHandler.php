<?php

/**
 * Class to handle all db operations
 * This class will have CRUD methods for database tables
 *
 **/
class DbHandler {

    private $conn;

    function __construct() {
        require_once dirname(__FILE__) . '/DbConnect.php';
        // opening db connection
        $db = new DbConnect();
        $this->conn = $db->connect();
    }

//----------------------Data analysis and extraction methods

    public function getDataBaseline($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM baseline WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }






    public function getDataHP1($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM hp1 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

    public function getDataHP2($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM hp2 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
	    public function getDataHP5($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM hp5 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

	    public function getDataHP10($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM hp10 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
	    public function getDataSH3($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM shannon3 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	    public function getDataSH5($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM shannon5 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
	    public function getDataSH10($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM shannon10 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	    public function getDataSH15($RansomwareName) {
        $stmt = $this->conn->prepare("SELECT * FROM shannon15 WHERE RansomwareName=?");
        $stmt->bind_param("s", $RansomwareName);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	

//------------------------Quick Tester methods
    public function getQuickRansomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `quicktester` WHERE Fetched is NULL limit 1");
        //$stmt->bind_param("s", $quicktester);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postQuickFetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE quicktester SET Fetched = CURRENT_TIMESTAMP WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postQuickPosted($RansomwareName, $FileChangedOnHash, $FileChangedOnWatcher, $Active){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE quicktester SET Posted = CURRENT_TIMESTAMP, FileChangedOnHash=?, FileChangedOnWatcher=?, Active=? WHERE RansomwareName=?");
            $stmt->bind_param("iiis", $FileChangedOnHash, $FileChangedOnWatcher, $Active, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }



    public function getQuickHost() {
        $stmt = $this->conn->prepare("SELECT * FROM quicktester WHERE Fetched IS NOT NULL AND Posted IS NULL AND Active IS NULL limit 1");
        //$stmt->bind_param("s", $quicktester);
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
//------------------------Baseline Tester methods

public function getBaseRansomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `quicktester` WHERE Active=1 AND TakenByBaseline is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }


 public function postBaseFetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO baseline (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postBasePosted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=? WHERE RansomwareName=?");
            $stmt->bind_param("ssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postBaseTaken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE quicktester SET TakenByBaseline = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postBaseTested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE quicktester SET TestedByBaseline = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
	    public function getBaseHost() {
        $stmt = $this->conn->prepare("SELECT * FROM baseline WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
	 public function postBaseStarted($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


//------------------------HoneyPot 1 PROCENT Tester methods
public function postHP1(){}
//posts all the information gathered


	public function getHP1Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByHP1 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postHP1Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO hp1 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postHP1Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp1 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postHP1Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByHP1 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postHP1Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByHP1 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getHP1Host() {
        $stmt = $this->conn->prepare("SELECT * FROM hp1 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

		 public function postHP1Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp1 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


//------------------------HoneyPot 2 PROCENT Tester methods
public function postHP2(){}
//posts all the information gathered


	public function getHP2Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByHP2 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postHP2Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO hp2 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postHP2Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp2 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postHP2Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByHP2 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postHP2Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByHP2 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getHP2Host() {
        $stmt = $this->conn->prepare("SELECT * FROM hp2 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
		 public function postHP2Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp2 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

	
//------------------------HoneyPot 5 PROCENT Tester methods
public function postHP5(){}
//posts all the information gathered


	public function getHP5Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByHP5 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postHP5Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO hp5 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postHP5Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp5 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postHP5Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByHP5 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postHP5Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByHP5 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getHP5Host() {
        $stmt = $this->conn->prepare("SELECT * FROM hp5 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
	
		 public function postHP5Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp5 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

	
//------------------------HoneyPot 10 PROCENT Tester methods
public function postHP10(){}
//posts all the information gathered


	public function getHP10Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByHP10 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postHP10Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO hp10 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postHP10Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp10 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postHP10Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByHP10 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postHP10Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByHP10 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getHP10Host() {
        $stmt = $this->conn->prepare("SELECT * FROM hp10 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }
			 public function postHP10Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE hp10 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

	//------------------------Shannon3 Tester methods
	
		public function postSH3(){}
//posts all the information gathered


	public function getSH3Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByShannon3 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postSH3Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO shannon3 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postSH3Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon3 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postSH3Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByShannon3 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postSH3Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByShannon3 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getSH3Host() {
        $stmt = $this->conn->prepare("SELECT * FROM shannon3 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

		 public function postSH3Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon3 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


	//------------------------shannon5 Tester methods
	
		public function postSH5(){}
//posts all the information gathered


	public function getSH5Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByShannon5 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postSH5Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO shannon5 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postSH5Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon5 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postSH5Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByShannon5 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postSH5Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByShannon5 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getSH5Host() {
        $stmt = $this->conn->prepare("SELECT * FROM shannon5 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

		 public function postSH5Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon5 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


	//------------------------shannon10 Tester methods
	
		public function postSH10(){}
//posts all the information gathered


	public function getSH10Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByShannon10 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postSH10Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO shannon10 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postSH10Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon10 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postSH10Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByShannon10 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postSH10Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByShannon10 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getSH10Host() {
        $stmt = $this->conn->prepare("SELECT * FROM shannon10 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

		 public function postSH10Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon10 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }	
	
	
	//------------------------shannon15 Tester methods
	
		public function postSH15(){}
//posts all the information gathered


	public function getSH15Ransomware() {
        $stmt = $this->conn->prepare("SELECT * FROM `baseline` WHERE TakenByShannon15 is NULL limit 1");
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

 public function postSH15Fetched($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("INSERT INTO shannon15 (RansomwareName, Fetched) VALUES(?, CURRENT_TIMESTAMP) ");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }

public function postSH15Posted($RansomwareName, $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon15 SET Posted = CURRENT_TIMESTAMP, MonitorStatus=?, MonitorCount=?, CountChangedFiles=?, CountDeletedFiles=?, CountNewFiles=?, CountFilemonObservations=?, CPU=?, RAM=?, HDD=?, ThreadCount=?, HandleCount=?, ListChangedFiles=?, ListDeletedFiles=?, ListNewFiles=?, ListFilemonObservations=?, NameOfShutdownRansomware=?, Detected=?, Shutdown=?  WHERE RansomwareName=?");
            $stmt->bind_param("sssssssssssssssssss", $MonitorStatus, $MonitorCount, $CountChangedFiles, $CountDeletedFiles, $CountNewFiles, $CountFilemonObservations, $CPU, $RAM, $HDD, $ThreadCount, $HandleCount, $ListChangedFiles, $ListDeletedFiles, $ListNewFiles, $ListFilemonObservations, $NameOfShutdownRansomware, $Detected, $Shutdown, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }


 public function postSH15Taken($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TakenByShannon15 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	

 public function postSH15Tested($RansomwareName){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE baseline SET TestedByShannon15 = 1 WHERE RansomwareName=?");
            $stmt->bind_param("s", $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
		    public function getSH15Host() {
        $stmt = $this->conn->prepare("SELECT * FROM shannon15 WHERE Posted IS NULL ORDER BY Fetched DESC limit 1");
        
        $stmt->execute();
        $nextRansom = $stmt->get_result();
        $stmt->close();
        return $nextRansom;
    }

		 public function postSH15Started($RansomwareName, $Started){
        $response = array();

            $stmt = $this->conn->prepare("UPDATE shannon15 SET Started =? WHERE RansomwareName=?");
            $stmt->bind_param("ss", $Started, $RansomwareName);
//            $stmt->bind_param();
            $result = $stmt->execute();

            $stmt->close();

            // Check for successful insertion
            if ($result) {
                // ratings successfully inserted
                return  $result;
            } else {
                // Failed to insert rating
                return DATA_POST_FAILED;
            }

        return $response;
    }
	
}

?>
